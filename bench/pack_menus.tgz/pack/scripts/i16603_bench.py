"""Long-chat lag benchmark for unslothai/unsloth#16603.

seed: build a realistic long thread through the API (open reasoning, tool calls, unique code
      fences, LaTeX, tables), deterministic by --seed.
measure: on a live Studio, idle thread, fresh context per rep: typing (keydown -> 2nd frame,
      CDP RecalcStyleDuration per key, burst wall time) and wheel scroll (long tasks, frame
      intervals, style/layout totals). Optional --css-arm label=dist serves only that dist's CSS.

  python scripts/i16603_bench.py seed --base-url URL --home HOME --turns 60 --out thread.json
  python scripts/i16603_bench.py measure --base-url URL --home HOME --thread TID --reps 3 --label x --out x.json
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import random
import statistics
import sys
import time
import urllib.request
from pathlib import Path

WORKSPACE = Path(os.environ.get("WORKSPACE") or Path(__file__).resolve().parents[1])
sys.path.insert(0, str(WORKSPACE))
sys.path.insert(0, str(WORKSPACE / "scripts"))

from pr_ui_scenes._common import api_post, studio_session  # noqa: E402
from studio_test_kit.auth import seed_init_script  # noqa: E402

PASSWORD = "r16656-bench-pass-1"
WORDS = ("buffer scheduler fibre observer commit layout token shard lane chunk boundary descriptor "
         "gradient tensor kernel adapter loss batch epoch checkpoint quantize attention cache rotary "
         "softmax logits sampler prompt template tokenizer vocabulary embedding residual norm").split()
TOOLS = ("web_search", "python", "terminal", "code_execution", "search_knowledge_base")
LANGS = (("python", "def f_{i}(x):\n    y = [k * {i} for k in range(x)]\n    return sum(y) / max(1, len(y))\n"),
         ("typescript", "export function g{i}(xs: number[]): number {{\n  return xs.reduce((a, b) => a + b * {i}, 0);\n}}\n"),
         ("bash", "for f in data/shard_{i}_*.jsonl; do\n  wc -l \"$f\" | awk '{{print $1}}'\ndone\n"),
         ("json", "{{\n  \"step\": {i},\n  \"lr\": 2e-4,\n  \"warmup\": {i}0,\n  \"targets\": [\"q_proj\", \"v_proj\"]\n}}\n"),
         ("rust", "fn h{i}(v: &[u32]) -> u64 {{\n    v.iter().map(|x| (*x as u64) * {i}).sum()\n}}\n"))


def prose(rng: random.Random, n: int) -> str:
    out, size = [], 0
    while size < n:
        s = " ".join(rng.choice(WORDS) for _ in range(rng.randint(8, 18))).capitalize() + "."
        out.append(s)
        size += len(s) + 1
    return " ".join(out)


def answer(rng: random.Random, t: int) -> str:
    parts = [prose(rng, 500), f"The update rule is $\\theta_{{t+1}} = \\theta_t - \\eta \\nabla L_{t}$ with $\\eta = 2\\times10^{{-4}}$."]
    for j in range(rng.randint(1, 3)):
        lang, tpl = LANGS[(t + j) % len(LANGS)]
        body = "".join(tpl.format(i=t * 10 + j + k) for k in range(rng.randint(4, 12)))
        parts += [prose(rng, 250), f"```{lang}\n# turn {t} block {j}\n{body}```"]
    parts += ["$$\n\\mathcal{L}_{%d} = -\\sum_{i=1}^{N} y_i \\log \\hat{y}_i + \\lambda \\lVert W \\rVert_2^2\n$$" % t,
              "| step | loss | lr |\n|---|---|---|\n" + "\n".join(f"| {t*100+k} | {rng.random():.4f} | 2e-4 |" for k in range(5)),
              "- " + "\n- ".join(prose(rng, 80) for _ in range(4)), prose(rng, 600)]
    return "\n\n".join(parts)


def tool_calls(rng: random.Random, t: int) -> list[dict]:
    out = []
    for i in range(rng.randint(0, 3)):
        name = TOOLS[(t + i) % len(TOOLS)]
        q = prose(rng, 160)
        args = {"query": q} if name in ("web_search", "search_knowledge_base") else {"code": q}
        out.append({"type": "tool-call", "toolCallId": f"call_{t}_{i}", "toolName": name,
                    "argsText": json.dumps(args), "args": args, "state": "result", "result": prose(rng, 700)})
    return out


def build_messages(tid: str, turns: int, seed: int) -> list[dict]:
    rng = random.Random(seed)
    t0 = 1_767_225_600_000
    msgs, parent = [], None
    for t in range(turns):
        uid, aid = f"{tid}-u{t}", f"{tid}-a{t}"
        msgs.append({"id": uid, "threadId": tid, "parentId": parent, "role": "user",
                     "content": [{"type": "text", "text": f"Question {t}: " + prose(rng, 300) + " Use `trainer.step()` here?"}],
                     "createdAt": t0 + 2 * t})
        parts = [{"type": "reasoning", "text": prose(rng, rng.randint(1500, 4000))}] + tool_calls(rng, t) + \
                [{"type": "text", "text": f"Answer {t}.\n\n" + answer(rng, t)}]
        msgs.append({"id": aid, "threadId": tid, "parentId": uid, "role": "assistant", "content": parts,
                     "createdAt": t0 + 2 * t + 1})
        parent = aid
    return msgs


def _put(session, path: str, payload: dict) -> dict:
    req = urllib.request.Request(session.base_url + path, data=json.dumps(payload).encode(), method="PUT",
                                 headers={"Content-Type": "application/json",
                                          "Authorization": f"Bearer {session.access_token}"})
    with urllib.request.urlopen(req, timeout=600) as resp:
        return json.loads(resp.read() or b"{}")


def cmd_seed(a) -> int:
    s = studio_session(a.base_url, Path(a.home), PASSWORD)
    tid = f"i16603-{a.turns}t-s{a.seed}"
    api_post(s, "/api/chat/threads", {"id": tid, "title": f"Long chat {a.turns} turns", "modelType": "base",
                                      "modelId": "unsloth/Qwen3-4B", "createdAt": 1_767_225_600_000,
                                      "updatedAt": 1_767_225_600_000})
    msgs = build_messages(tid, a.turns, a.seed)
    _put(s, f"/api/chat/threads/{tid}/messages", {"messages": msgs, "pruneMissing": True})
    chars = sum(len(p.get("text", "") or "") + len(p.get("result", "") or "") for m in msgs for p in m["content"])
    info = {"thread": tid, "messages": len(msgs), "chars": chars, "approx_tokens": chars // 4}
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    Path(a.out).write_text(json.dumps(info))
    print(json.dumps(info))
    return 0


PROBE = """() => {
  window.__lat = []; window.__lt = []; window.__frames = [];
  const box = document.querySelector('form textarea');
  box.addEventListener('keydown', (e) => { const t0 = e.timeStamp;
    requestAnimationFrame(() => requestAnimationFrame(() => window.__lat.push(performance.now() - t0))); }, {capture: true});
  new PerformanceObserver((l) => { for (const e of l.getEntries()) window.__lt.push([e.startTime, e.duration]); })
    .observe({type: 'longtask', buffered: false});
  let last = performance.now();
  const tick = (now) => { window.__frames.push(now - last); last = now; window.__raf = requestAnimationFrame(tick); };
  window.__raf = requestAnimationFrame(tick);
  return true;
}"""

STATE = """() => ({
  nodes: document.getElementsByTagName('*').length,
  messages: document.querySelectorAll('[data-message-id]').length,
  reasoning_open: document.querySelectorAll('[data-state="open"]').length,
  code_blocks: document.querySelectorAll('[data-streamdown="code-block"]').length,
  katex: document.querySelectorAll('.katex').length,
  glass: document.documentElement.getAttribute('data-glass'),
  reduced: document.documentElement.classList.contains('force-reduced-motion'),
})"""


async def metrics(cdp) -> dict:
    return {m["name"]: m["value"] for m in (await cdp.send("Performance.getMetrics"))["metrics"]}


def window_stats(lt: list, frames: list, t_from: float, t_to: float) -> dict:
    lts = [d for (s, d) in lt if t_from <= s <= t_to]
    return {"longtasks": len(lts), "longtask_ms": round(sum(lts), 1), "longtask_max": round(max(lts, default=0), 1),
            "frame_p95": round(sorted(frames)[int(0.95 * (len(frames) - 1))], 1) if frames else None,
            "frame_max": round(max(frames, default=0), 1)}


async def one_rep(browser, base_url, init, tid, css, keys, burst) -> dict:
    ctx = await browser.new_context(viewport={"width": 1440, "height": 900})
    if css is not None:
        served = {"n": 0}

        async def handle(route):
            served["n"] += 1
            await route.fulfill(status=200, content_type="text/css", body=css if served["n"] == 1 else "")
        await ctx.route("**/assets/*.css", handle)
    await ctx.add_init_script(init)
    page = await ctx.new_page()
    await page.goto(f"{base_url}/chat?thread={tid}", wait_until="domcontentloaded")
    box = page.locator("form textarea").first
    await box.wait_for(state="visible", timeout=240_000)
    await page.wait_for_function("() => document.body.innerText.includes('Answer ')", timeout=240_000)
    await page.wait_for_timeout(6000)
    state = await page.evaluate(STATE)
    await box.click()
    await page.evaluate(PROBE)
    cdp = await ctx.new_cdp_session(page)
    await cdp.send("Performance.enable")
    out = {"state": state}
    # typing
    m0 = await metrics(cdp)
    t_a = await page.evaluate("() => performance.now()")
    for ch in keys:
        await page.keyboard.press("Space" if ch == " " else ch)
        await page.wait_for_timeout(120)
    await page.wait_for_timeout(500)
    t_b = await page.evaluate("() => performance.now()")
    m1 = await metrics(cdp)
    lat = await page.evaluate("() => window.__lat.slice()")
    lt = await page.evaluate("() => window.__lt.slice()")
    out["type"] = {"style_ms_per_key": round(1000 * (m1["RecalcStyleDuration"] - m0["RecalcStyleDuration"]) / len(keys), 2),
                   "layout_ms_per_key": round(1000 * (m1["LayoutDuration"] - m0["LayoutDuration"]) / len(keys), 2),
                   "lat_median": round(statistics.median(lat), 1) if lat else None,
                   "lat_p95": round(sorted(lat)[int(0.95 * (len(lat) - 1))], 1) if lat else None,
                   **window_stats(lt, [], t_a, t_b)}
    await box.fill("")
    await page.wait_for_timeout(400)
    t = time.perf_counter()
    await page.keyboard.type(burst, delay=0)
    await page.wait_for_function("(s) => document.querySelector('form textarea').value === s", arg=burst, timeout=240_000)
    await page.evaluate("() => new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)))")
    out["type"]["burst_s"] = round(time.perf_counter() - t, 2)
    out["type"]["text_ok"] = (await box.input_value()) == burst
    await box.fill("")
    await page.wait_for_timeout(600)
    # scroll: wheel up over the thread then back down
    await page.mouse.move(720, 400)
    m0 = await metrics(cdp)
    await page.evaluate("() => { window.__frames = []; }")
    t_a = await page.evaluate("() => performance.now()")
    for i in range(60):
        await page.mouse.wheel(0, -700 if i < 30 else 700)
        await page.wait_for_timeout(40)
    await page.wait_for_timeout(800)
    t_b = await page.evaluate("() => performance.now()")
    m1 = await metrics(cdp)
    lt = await page.evaluate("() => window.__lt.slice()")
    frames = await page.evaluate("() => window.__frames.slice()")
    out["scroll"] = {"style_ms": round(1000 * (m1["RecalcStyleDuration"] - m0["RecalcStyleDuration"]), 1),
                     "layout_ms": round(1000 * (m1["LayoutDuration"] - m0["LayoutDuration"]), 1),
                     "script_ms": round(1000 * (m1["ScriptDuration"] - m0["ScriptDuration"]), 1),
                     **window_stats(lt, frames, t_a, t_b)}
    await ctx.close()
    return out


def med(xs):
    xs = [x for x in xs if x is not None]
    return round(statistics.median(xs), 2) if xs else None


async def cmd_measure(a) -> int:
    from playwright.async_api import async_playwright
    s = studio_session(a.base_url, Path(a.home), PASSWORD)
    auth = type("A", (), {"access_token": s.access_token, "refresh_token": s.refresh_token})()
    ls = {"unsloth_window_material": json.dumps({"state": {"material": a.material}, "version": 0})}
    init = seed_init_script(auth, [], extra_local_storage=ls)
    arms = {}
    for spec in a.css_arm:
        k, v = spec.split("=", 1)
        arms[k] = "\n".join(f.read_text() for f in sorted((Path(v) / "assets").glob("*.css")))
    if not arms:
        arms = {a.label: None}
    names = list(arms)
    keys = "hello world typing test"
    burst = "the quick brown fox jumps over the lazy dog " * 2
    res: dict = {k: [] for k in names}
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        for r in range(a.reps):
            for arm in names[r % len(names):] + names[:r % len(names)]:
                try:
                    o = await one_rep(browser, a.base_url, init, a.thread, arms[arm], keys, burst)
                except Exception as exc:  # noqa: BLE001 -- slow page load on a loaded host: one retry
                    print(f"[{arm}] retry after {type(exc).__name__}: {str(exc)[:120]}", flush=True)
                    o = await one_rep(browser, a.base_url, init, a.thread, arms[arm], keys, burst)
                res[arm].append(o)
                print(f"rep{r} {arm}: type={o['type']} scroll={o['scroll']} state={o['state']}", flush=True)
        await browser.close()
    summary = {}
    for arm, reps in res.items():
        summary[arm] = {
            "type_style_ms_per_key": med([x["type"]["style_ms_per_key"] for x in reps]),
            "type_lat_median": med([x["type"]["lat_median"] for x in reps]),
            "type_lat_p95": med([x["type"]["lat_p95"] for x in reps]),
            "type_burst_s": med([x["type"]["burst_s"] for x in reps]),
            "scroll_style_ms": med([x["scroll"]["style_ms"] for x in reps]),
            "scroll_layout_ms": med([x["scroll"]["layout_ms"] for x in reps]),
            "scroll_script_ms": med([x["scroll"]["script_ms"] for x in reps]),
            "scroll_longtask_ms": med([x["scroll"]["longtask_ms"] for x in reps]),
            "scroll_frame_p95": med([x["scroll"]["frame_p95"] for x in reps]),
            "scroll_frame_max": med([x["scroll"]["frame_max"] for x in reps]),
            "text_ok": all(x["type"]["text_ok"] for x in reps),
            "state": reps[0]["state"],
        }
        print("SUMMARY", json.dumps({"label": arm, "material": a.material, **summary[arm]}), flush=True)
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    Path(a.out).write_text(json.dumps({"summary": summary, "reps": res}, indent=1))
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    sp = ap.add_subparsers(dest="cmd", required=True)
    s1 = sp.add_parser("seed")
    s1.add_argument("--base-url", required=True)
    s1.add_argument("--home", required=True)
    s1.add_argument("--turns", type=int, default=60)
    s1.add_argument("--seed", type=int, default=16603)
    s1.add_argument("--out", required=True)
    s2 = sp.add_parser("measure")
    s2.add_argument("--base-url", required=True)
    s2.add_argument("--home", required=True)
    s2.add_argument("--thread", required=True)
    s2.add_argument("--label", default="arm")
    s2.add_argument("--material", default="solid")
    s2.add_argument("--reps", type=int, default=3)
    s2.add_argument("--css-arm", action="append", default=[])
    s2.add_argument("--out", required=True)
    a = ap.parse_args()
    if a.cmd == "seed":
        return cmd_seed(a)
    return asyncio.run(cmd_measure(a))


if __name__ == "__main__":
    raise SystemExit(main())

"""The two checks that turn a silent screenshot failure into a non-zero exit.

Both failures they cover produce output indistinguishable from a successful run: the
driver installs twice, drives the scene twice, composes a clean labelled pair, and
prints it. Until these existed the only thing standing between that and a PR comment
was a human remembering to open the PNG, and the most common cause is not "the PR
changed nothing" but a missed click, the wrong dropdown, or a stale home.

Run: python3 pr_ui_scenes/test_pr_ui_diff_guards.py
"""

from __future__ import annotations

import sys
import tempfile
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(SCRIPTS))

from pr_ui_diff import _facts_diff, _same_bytes  # noqa: E402

_FAILS = 0


def _check(name: str, got, want) -> None:
    """RAISES on mismatch, rather than counting.

    A soft counter is only checked by `main()`, and pytest collects the `test_*`
    functions and never calls `main()`. Wired into pytest, a counting `_check`
    makes the whole file pass while every check inside it fails. `main()` catches
    per test below, so running this as a script still reports all of them.
    """
    if got != want:
        raise AssertionError(f"{name}: got {got!r}, want {want!r}")
    print(f"ok    {name}")


def test_same_bytes() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        d = Path(tmp)
        a, b, c = d / "a.png", d / "b.png", d / "c.png"
        a.write_bytes(b"\x89PNG" + b"x" * 100)
        b.write_bytes(b"\x89PNG" + b"x" * 100)   # same content, different file
        c.write_bytes(b"\x89PNG" + b"y" * 100)   # same SIZE, different content
        _check("identical content is caught", _same_bytes(a, b), True)
        # Size equality alone must not be enough: a scene that photographs the same
        # panel with one label changed produces same-size, different-content files.
        _check("same size but different content is not identical", _same_bytes(a, c), False)
        _check("a missing file is not identical", _same_bytes(a, d / "nope.png"), False)


def test_facts_diff() -> None:
    _check("no change reads as empty", _facts_diff({"rows": 4}, {"rows": 4}), {})
    _check("a moved value is reported",
           _facts_diff({"rows": 4}, {"rows": 18}), {"rows": (4, 18)})
    # A key only one side could read is itself the finding, not something to skip.
    _check("a key missing on one side counts",
           _facts_diff({"quant": "Q4"}, {}), {"quant": ("Q4", None)})
    _check("a key added by the head counts",
           _facts_diff({}, {"quant": "Q4"}), {"quant": (None, "Q4")})
    # Order within a list is part of the value: a picker that reorders rows changed.
    _check("list order is part of the value",
           _facts_diff({"opts": ["a", "b"]}, {"opts": ["b", "a"]}),
           {"opts": (["a", "b"], ["b", "a"])})


def test_harness_facts_are_excluded() -> None:
    """`_`-prefixed keys are the scene's own bookkeeping, not readings off the UI.

    An ephemeral server port, a server-minted provider id and a per-side video path
    differ between the halves BY CONSTRUCTION. Counting them would make a parity plan
    fail every correct run, and would let an ordinary plan satisfy "some fact moved"
    without one fact about the UI having moved.
    """
    _check("an underscored key never counts as a difference",
           _facts_diff({"_server_port": 41001, "rows": 4},
                       {"_server_port": 55123, "rows": 4}),
           {})
    _check("a real key still counts alongside an underscored one",
           _facts_diff({"_video": "a.webm", "rows": 4},
                       {"_video": "b.webm", "rows": 18}),
           {"rows": (4, 18)})


def test_port_bands() -> None:
    """Two workspaces must not scan the same range from the same base."""
    import os

    from pr_ui_scenes._common import _workspace_port_base, pick_free_ports

    seen = set()
    for root in ("/mnt/x/workspace_1", "/mnt/x/workspace_19", "/mnt/x/workspace_7"):
        os.environ["WORKSPACE"] = root
        seen.add(_workspace_port_base())
    _check("different workspaces get different bases", len(seen), 3)
    os.environ["WORKSPACE"] = "/mnt/x/workspace_19"
    _check("the same workspace is stable across calls",
           _workspace_port_base(), _workspace_port_base())

    # Port 0 BINDS FINE -- the kernel hands out an ephemeral port -- so without an
    # explicit range check it is returned as a "free port" and Studio launches on
    # `-p 0`. A port above 65535 raises OverflowError, which the scan loop's
    # `except OSError` does not catch.
    for bad in ("0", "70000", "notaport"):
        os.environ["UIDIFF_PORT_START"] = bad
        try:
            pick_free_ports(1)
            _check(f"UIDIFF_PORT_START={bad} is rejected", "accepted", "ValueError")
        except ValueError:
            _check(f"UIDIFF_PORT_START={bad} is rejected", "ValueError", "ValueError")
    os.environ.pop("UIDIFF_PORT_START", None)


def test_password_is_per_home() -> None:
    """One password per PAIR cannot tell home_before from home_after apart.

    `studio_session` sells the login as proof of WHICH install answered. With a
    shared credential the likeliest squatter of all -- the sibling side, launched by
    the same toolkit from the same band under the same root -- logs in happily, and
    the driver then photographs, and deletes threads from, the wrong Studio.
    """
    from pr_ui_diff import password_for

    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        before, after = root / "home_before", root / "home_after"
        for home in (before, after):
            (home / "auth").mkdir(parents=True)
        pw_b, pw_a = password_for(root, before), password_for(root, after)
        _check("the two homes get different passwords", pw_b != pw_a, True)
        _check("a password is stable across calls", password_for(root, before), pw_b)

        # Migration: a home rotated by an older run accepts only the shared
        # password, and nothing but a reinstall can change that.
        legacy_root = Path(tmp) / "legacy"
        legacy_home = legacy_root / "home_before"
        legacy_home.mkdir(parents=True)
        (legacy_root / "studio_password.txt").write_text("old-shared-pw")
        _check("an already-rotated home keeps the shared password",
               password_for(legacy_root, legacy_home), "old-shared-pw")
        # One still holding a bootstrap file has not rotated, so it can take a new one.
        fresh = legacy_root / "home_after"
        (fresh / "auth").mkdir(parents=True)
        (fresh / "auth" / ".bootstrap_password").write_text("boot")
        _check("an unrotated home gets a fresh password",
               password_for(legacy_root, fresh) != "old-shared-pw", True)


def test_parity_inverts_the_guard() -> None:
    """A parity plan claims the UI does NOT change, so the guard inverts.

    The dangerous output is the same in both directions: a pair that looks clean and
    proves nothing. On an ordinary plan that is two matching halves; on a parity plan
    it is two matching BLANK halves, which is also what a perfect result looks like.
    """
    from pr_ui_diff import _problems

    good_facts = {"BEFORE": {"reply_sha256": "ab"}, "AFTER": {"reply_sha256": "ab"}}

    # Ordinary plan: matching halves are the failure.
    _check("ordinary plan fails on identical shots",
           bool(_problems(False, ["a.png == b.png"], {"rows": (4, 18)}, good_facts)), True)
    _check("ordinary plan fails when no fact moved",
           bool(_problems(False, [], {}, good_facts)), True)
    _check("ordinary plan passes on a real difference",
           _problems(False, [], {"rows": (4, 18)}, good_facts), [])

    # Parity plan: the same inputs mean the opposite.
    _check("parity plan PASSES on identical shots with matching facts",
           _problems(True, ["a.png == b.png"], {}, good_facts), [])
    _check("parity plan fails when a fact moved",
           bool(_problems(True, [], {"reply_sha256": ("ab", "cd")}, good_facts)), True)
    # The one that matters: a scene that rendered nothing also produces two matching
    # halves, and without this it reads as a perfect parity result.
    _check("parity plan fails when a side read nothing",
           bool(_problems(True, ["a.png == b.png"], {},
                          {"BEFORE": {}, "AFTER": {"reply_sha256": "ab"}})), True)


def test_every_plan_has_its_scene() -> None:
    """A plan naming a module that does not ship must fail at PLAN time.

    The driver imports the scene only after resolving SHAs and installing both
    sides, so this otherwise surfaces tens of minutes in, on a machine that has
    already built twice.
    """
    from pr_ui_scenes.registry import missing_scenes

    _check("every registered plan has a scene module", missing_scenes(), {})


def test_resolve_plan() -> None:
    """A PR nobody registered must be runnable, but never without `expect`.

    Editing registry.py was the one step in this workflow that cannot be
    scripted, so it was the one most likely to be skipped in a hurry. `--scene`
    plus `--expect` shoots an unregistered PR; `--expect` stays mandatory there
    because a scene that photographs the wrong thing looks exactly like one that
    worked, and an `expect` written afterwards just describes whatever came out.
    """
    from types import SimpleNamespace

    from pr_ui_diff import resolve_plan

    def args(**kw):
        base = dict(pr=999999, scene=None, expect=None, what=None, scene_kwargs=None,
                    needs_model=False, parity=False)
        base.update(kw)
        return SimpleNamespace(**base)

    for bad, why in (
        (args(), "unregistered PR with no --scene"),
        (args(scene="gguf_picker_rows"), "unregistered PR with no --expect"),
        (args(scene="no_such_scene", expect="x"), "a scene module that does not exist"),
    ):
        try:
            resolve_plan(bad)
            _check(f"refuses {why}", "accepted", "SystemExit")
        except SystemExit:
            _check(f"refuses {why}", "SystemExit", "SystemExit")

    plan = resolve_plan(args(scene="gguf_picker_rows", expect="4 rows -> 18 rows",
                             scene_kwargs='{"repo": "org/x"}'))
    _check("ad hoc plan takes the scene", plan.scene, "gguf_picker_rows")
    _check("ad hoc plan takes expect", plan.expect, "4 rows -> 18 rows")
    _check("ad hoc plan takes kwargs", plan.kwargs, {"repo": "org/x"})
    _check("ad hoc plan is not parity by default", plan.parity, False)
    _check("--parity reaches the plan",
           resolve_plan(args(scene="gguf_picker_rows", expect="both show x",
                             parity=True)).parity, True)

    # A registered PR keeps its plan, and CLI kwargs MERGE over it rather than
    # replacing it: dropping the rest of a plan's kwargs silently changes what
    # the scene drives.
    merged = resolve_plan(args(pr=8255, scene_kwargs='{"repo": "org/y"}'))
    _check("registered kwargs are merged, not replaced",
           merged.kwargs["repo"] == "org/y" and "clip" in merged.kwargs, True)
    _check("a registered plan keeps its expect",
           resolve_plan(args(pr=8255)).expect.startswith("4 rows"), True)
    _check("--scene-kwargs that is not JSON is refused",
           _raises_systemexit(resolve_plan, args(pr=8255, scene_kwargs="{oops")), True)


def _raises_systemexit(fn, *a) -> bool:
    try:
        fn(*a)
    except SystemExit:
        return True
    return False


def main() -> int:
    failures = 0
    for test in (test_same_bytes, test_facts_diff, test_parity_inverts_the_guard,
                 test_harness_facts_are_excluded, test_port_bands,
                 test_password_is_per_home, test_every_plan_has_its_scene,
                 test_resolve_plan):
        try:
            test()
        except AssertionError as exc:
            print(f"FAIL  {exc}", file=sys.stderr)
            failures += 1
    print()
    print("FAILED" if failures else "all guard checks passed")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())


def test_pick_free_ports_skips_browser_blocked_ports() -> None:
    """A Studio on a port Chromium refuses (ERR_UNSAFE_PORT) shows nothing to Playwright."""
    import socket

    import pytest

    from pr_ui_scenes._common import pick_free_ports

    probe = socket.socket()
    probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        probe.bind(("127.0.0.1", 10080))
    except OSError:
        pytest.skip("10080 is taken on this host, so the refusal would prove nothing")
    finally:
        probe.close()
    with pytest.raises(RuntimeError):
        pick_free_ports(1, start=10080, stop=10081)

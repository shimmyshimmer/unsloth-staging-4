"""Every scene's calls into `studio_test_kit` match the kit's real signatures.

This exists because of a bug that made an entire 933-line scene dead code: it called
`open_chat(..., bypass_csp=True)` against an `open_chat` that has no such parameter
and no `**kwargs`. That is a TypeError at call time, before a browser ever opens, and
nothing caught it -- the scene had been developed against a locally-patched kit, and
the patch was never committed. A scene is only ever exercised by a full two-install
driver run costing tens of minutes, so an arity mistake surfaces after the first
install rather than in a second here.

Static on purpose: no Studio, no browser, no network. It reads the scene with `ast`
and the kit with `inspect`, so it says nothing about whether a scene WORKS, only that
its calls into the kit can be made at all.

Run: python3 pr_ui_scenes/test_scene_kit_calls.py
"""

from __future__ import annotations

import ast
import importlib
import inspect
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SCRIPTS = HERE.parent
sys.path.insert(0, str(SCRIPTS))

_FAILS = 0

# The modules a scene is allowed to reach into, and which this test can resolve.
KIT_MODULES = ("studio_test_kit.ui", "studio_test_kit.auth", "studio_test_kit.lifecycle",
               "studio_test_kit.flows", "pr_ui_scenes._common")


def _fail(msg: str) -> None:
    global _FAILS
    print(f"FAIL  {msg}", file=sys.stderr)
    _FAILS += 1


def _imported_names(tree: ast.Module) -> dict[str, str]:
    """`{local name: defining module}` for every `from <kit module> import x`."""
    found: dict[str, str] = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module in KIT_MODULES:
            for alias in node.names:
                found[alias.asname or alias.name] = node.module
    return found


def _check_scene(path: Path) -> None:
    tree = ast.parse(path.read_text())
    imported = _imported_names(tree)
    if not imported:
        return
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Name):
            continue
        origin = imported.get(node.func.id)
        if origin is None:
            continue
        func = getattr(importlib.import_module(origin), node.func.id, None)
        if func is None or isinstance(func, type) or not callable(func):
            continue
        try:
            sig = inspect.signature(func)
        except (TypeError, ValueError):
            continue
        # A `**kwargs` parameter accepts anything, so there is nothing to check.
        if any(p.kind is p.VAR_KEYWORD for p in sig.parameters.values()):
            continue
        accepted = set(sig.parameters)
        for kw in node.keywords:
            if kw.arg is None:          # `**something`, opaque to this check
                continue
            if kw.arg not in accepted:
                _fail(
                    f"{path.name}:{node.lineno} calls {node.func.id}({kw.arg}=...) but "
                    f"{origin}.{node.func.id} accepts only {sorted(accepted)}. This is a "
                    f"TypeError at call time, so the scene cannot run at all."
                )
                continue
        # Too many positional arguments is the same class of breakage.
        positional = [p for p in sig.parameters.values()
                      if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)]
        has_varargs = any(p.kind is p.VAR_POSITIONAL for p in sig.parameters.values())
        given = len([a for a in node.args if not isinstance(a, ast.Starred)])
        if not has_varargs and given > len(positional):
            _fail(
                f"{path.name}:{node.lineno} passes {given} positional argument(s) to "
                f"{node.func.id}, which takes {len(positional)}"
            )


def main() -> int:
    scenes = sorted(p for p in HERE.glob("*.py")
                    if not p.name.startswith(("test_", "_")) and p.name != "registry.py")
    for scene in scenes:
        _check_scene(scene)
        print(f"ok    {scene.name} calls the kit with signatures it has")
    print()
    print("FAILED" if _FAILS else f"all {len(scenes)} scene(s) match the kit")
    return 1 if _FAILS else 0


if __name__ == "__main__":
    raise SystemExit(main())

"""Browser-pane open/close attribution on a long thread: one build, runtime variants.

  python pane_probe.py --base-url URL --home HOME --threads threads.json --arm main \
      --engines webkit,chromium --variants stock,noanim,nocontain,floor --turns 1 150 --reps 2 --out x.json

Variants (fresh context each; the build is the same):
  stock      as shipped
  noanim     the panel flex-basis transition is off (the width changes in one step)
  nocontain  message-row containment forced off (__UNSLOTH_MESSAGE_ROW_CONTAINMENT__ = false)
  contain    message-row containment forced on (for engines whose probe turns it off)
  floor      message rows display:none (pane cost without the thread's layout)
Per open/close: rAF gaps for 2.5 s after the click (max, sum over 50 ms, count), time to the tab bar,
when the split's data-artifact-layout-animating flips, how many width changes the thread viewport saw
(ResizeObserver, no forced layout), and on Chromium CDP Layout / RecalcStyle / Script durations.
"""

import argparse
import asyncio
import json
import os
import statistics
import sys
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument("--base-url", required=True)
ap.add_argument("--home", required=True)
ap.add_argument("--threads", required=True)
ap.add_argument("--arm", required=True)
ap.add_argument("--engines", default="webkit,chromium")
ap.add_argument("--variants", default="stock,noanim,nocontain,floor")
ap.add_argument("--turns", nargs="+", default=["1", "150"])
ap.add_argument("--reps", type=int, default=2)
ap.add_argument("--cycles", type=int, default=3)
ap.add_argument("--pack", default=os.environ.get("PACK", ""))
ap.add_argument("--out", required=True)
a = ap.parse_args()
sys.path.insert(0, a.pack or str(Path(__file__).resolve().parent))
import menu_bench as mb  # noqa: E402

VARIANT_CSS = {
    "noanim": '.chat-artifact-split[data-artifact-layout-animating="true"] > [data-panel] { transition: none !important; }',
    "floor": ".aui-thread-viewport [data-role][data-message-id] { display: none !important; }",
}
VARIANT_INIT = {
    "nocontain": "globalThis.__UNSLOTH_MESSAGE_ROW_CONTAINMENT__ = false;",
    "contain": "globalThis.__UNSLOTH_MESSAGE_ROW_CONTAINMENT__ = true;",
}
VP = "document.querySelector('.aui-thread-viewport')"
STATE_JS = f"""() => {{ const v = {VP}; const rows = v ? v.querySelectorAll('[data-role][data-message-id]') : [];
  return {{ attr: document.documentElement.getAttribute('data-message-row-containment'),
    anchor_name: CSS.supports('anchor-name: --x'), ua: navigator.userAgent.slice(0, 120),
    rows: rows.length, distant: v ? v.querySelectorAll('[data-row-distant]').length : null,
    parked: v ? v.querySelectorAll('[data-message-parked]').length : null,
    width: v ? v.clientWidth : null, nodes: document.getElementsByTagName('*').length }}; }}"""
REC_START = f"""() => {{ window.__f = []; window.__t0 = performance.now(); window.__rec = true; window.__ready = null;
  window.__anim = []; window.__widths = 0;
  const split = document.querySelector('.chat-artifact-split');
  window.__mo = new MutationObserver(() => window.__anim.push([Math.round(performance.now() - window.__t0),
    split.getAttribute('data-artifact-layout-animating')]));
  if (split) window.__mo.observe(split, {{attributes: true, attributeFilter: ['data-artifact-layout-animating']}});
  const v = {VP}; let first = true;
  window.__ro = new ResizeObserver(() => {{ if (first) {{ first = false; return; }} window.__widths++; }});
  if (v) window.__ro.observe(v);
  const tick = (ts) => {{ if (!window.__rec) return; window.__f.push(ts);
    if (window.__ready === null && window.__want && window.__want()) window.__ready = ts - window.__t0;
    requestAnimationFrame(tick); }};
  requestAnimationFrame(tick); }}"""
REC_STOP = """() => { window.__rec = false; window.__mo.disconnect(); window.__ro.disconnect();
  const f = window.__f; const g = [];
  for (let i = 1; i < f.length; i++) g.push(f[i] - f[i - 1]);
  const big = g.map((x, i) => [Math.round(f[i] - window.__t0), Math.round(x)]).filter(([, x]) => x > 50);
  return {first_ms: f.length ? Math.round(f[0] - window.__t0) : null,
          ready_ms: window.__ready === null ? null : Math.round(window.__ready),
          max_gap: g.length ? Math.round(Math.max(...g)) : null,
          over50_ms: Math.round(g.filter((x) => x > 50).reduce((s, x) => s + x, 0)),
          frames: f.length, big: big.slice(0, 12), anim: window.__anim, width_changes: window.__widths}; }"""
CLICK_JS = """(sel) => { const all = [...document.querySelectorAll(sel)].filter((e) => e.getBoundingClientRect().width > 0);
  const el = all.sort((x, y) => y.getBoundingClientRect().x - x.getBoundingClientRect().x)[0] || document.querySelector(sel);
  if (!el) return false; el.dispatchEvent(new PointerEvent('pointerdown', {bubbles: true})); el.click(); return true; }"""
OPEN = ('button[aria-label="New tab"]', "() => !!document.querySelector('[aria-label=\"Browser tabs\"]')")
CLOSE = ('button[aria-label="Close browser"]', "() => !document.querySelector('[aria-label=\"Browser tabs\"]')")


async def metrics(cdp):
    if cdp is None:
        return None
    return {m["name"]: m["value"] for m in (await cdp.send("Performance.getMetrics"))["metrics"]}


async def timed(page, cdp, sel, want_js):
    await page.evaluate(f"() => {{ window.__want = {want_js}; }}")
    before = await metrics(cdp)
    await page.evaluate(REC_START)
    if not await page.evaluate(CLICK_JS, sel):
        raise RuntimeError(f"no {sel}")
    await page.wait_for_timeout(2500)
    r = await page.evaluate(REC_STOP)
    after = await metrics(cdp)
    if before:
        for k, name in (("layout_ms", "LayoutDuration"), ("style_ms", "RecalcStyleDuration"), ("script_ms", "ScriptDuration")):
            r[k] = round(1000 * (after[name] - before[name]), 1)
    return r


async def one_run(p, engine, variant, info):
    s = mb.studio_session(a.base_url, Path(a.home), mb.PASSWORD)
    auth = type("A", (), {"access_token": s.access_token, "refresh_token": s.refresh_token})()
    launcher = {"webkit": p.webkit, "webkit_mac": p.webkit, "chromium": p.chromium, "msedge": p.chromium}[engine]
    b = await (launcher.launch(channel="msedge") if engine == "msedge" else launcher.launch())
    try:
        extra = {"user_agent": mb.MAC_UA} if engine == "webkit_mac" else {}
        ctx = await b.new_context(viewport={"width": 1440, "height": 900}, **extra)
        if engine == "webkit_mac":
            await ctx.add_init_script("Object.defineProperty(Navigator.prototype, 'platform', {get: () => 'MacIntel'});")
        await ctx.add_init_script(mb.seed_init_script(auth, []))
        if variant in VARIANT_INIT:
            await ctx.add_init_script(VARIANT_INIT[variant])
        page = await ctx.new_page()
        cdp = await ctx.new_cdp_session(page) if engine in ("chromium", "msedge") else None
        if cdp:
            await cdp.send("Performance.enable")
        await page.goto(f"{a.base_url}/chat?thread={info['thread']}", wait_until="domcontentloaded")
        await page.wait_for_selector("form textarea", timeout=180_000)
        for _ in range(900):
            if await page.evaluate("() => document.querySelectorAll('[data-role][data-message-id]').length") >= info["messages"]:
                break
            await page.wait_for_timeout(200)
        await page.wait_for_timeout(3000)
        if variant in VARIANT_CSS:
            await page.add_style_tag(content=VARIANT_CSS[variant])
            await page.wait_for_timeout(500)
        out = {"engine": engine, "variant": variant, "state": await page.evaluate(STATE_JS), "cycles": []}
        for _ in range(a.cycles):
            o = await timed(page, cdp, *OPEN)
            o["width"] = await page.evaluate(f"() => {VP}.clientWidth")
            c = await timed(page, cdp, *CLOSE)
            out["cycles"].append({"open": o, "close": c})
        out["state_after"] = await page.evaluate(STATE_JS)
        await ctx.close()
        return out
    finally:
        await b.close()


def med(xs):
    xs = [x for x in xs if x is not None]
    return round(statistics.median(xs), 1) if xs else None


async def main():
    from playwright.async_api import async_playwright
    threads = json.loads(Path(a.threads).read_text())
    runs = []
    async with async_playwright() as p:
        for rep in range(a.reps):
            for engine in a.engines.split(","):
                for turns in a.turns:
                    variants = a.variants.split(",") if turns != "1" else ["stock"]
                    order = variants if rep % 2 == 0 else list(reversed(variants))
                    for variant in order:
                        try:
                            r = await one_run(p, engine, variant, threads[str(turns)])
                        except Exception as exc:  # noqa: BLE001
                            print("PANE_ERR", a.arm, engine, turns, variant, rep, repr(exc)[:300], flush=True)
                            continue
                        r.update(arm=a.arm, turns=turns, rep=rep)
                        runs.append(r)
                        op = [x["open"] for x in r["cycles"]]
                        cl = [x["close"] for x in r["cycles"]]
                        print("PANE", a.arm, engine, turns, variant, rep, json.dumps({
                            "state": {k: r["state"].get(k) for k in ("attr", "anchor_name", "rows", "distant", "width")},
                            "open_gap": [x["max_gap"] for x in op], "open_over50": [x["over50_ms"] for x in op],
                            "open_ready": [x["ready_ms"] for x in op], "open_widths": [x["width_changes"] for x in op],
                            "close_gap": [x["max_gap"] for x in cl], "close_over50": [x["over50_ms"] for x in cl],
                            "open_layout": [x.get("layout_ms") for x in op], "open_style": [x.get("style_ms") for x in op],
                            "open_script": [x.get("script_ms") for x in op], "close_layout": [x.get("layout_ms") for x in cl],
                            "open_big": op[-1]["big"], "anim": op[-1]["anim"]}), flush=True)
                        Path(a.out).write_text(json.dumps(runs, indent=1))


asyncio.run(main())

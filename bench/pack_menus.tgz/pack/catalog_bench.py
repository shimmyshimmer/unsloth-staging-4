"""PR unslothai/unsloth#16831 bench: the listing read aloud waits on before each utterance.

Against a live Studio whose HF cache was seeded by the driver: GET /v1/models (what main's read
aloud lists) once the 30 s catalog cache has expired, and inside it, against
GET /api/inference/loaded-models (what the PR lists). Then loads a small GGUF chat model and
checks that both listings report the same loaded rows (the PR's equivalence claim).

  python catalog_bench.py --base-url URL --home HOME --out x.json [--load REPO:VARIANT]
"""

from __future__ import annotations

import argparse
import json
import os
import statistics
import sys
import time
import urllib.request
from pathlib import Path

sys.path.insert(0, os.environ.get("PACK", str(Path(__file__).resolve().parent)))

from pr_ui_scenes._common import api_get, api_post, studio_session  # noqa: E402

PASSWORD = "r16656-bench-pass-1"


def timed_get(base, token, path):
    req = urllib.request.Request(base + path, headers={"Authorization": f"Bearer {token}"})
    t = time.perf_counter()
    with urllib.request.urlopen(req, timeout=600) as r:
        body = json.loads(r.read() or b"{}")
    return time.perf_counter() - t, body


def loaded_rows(body):
    out = []
    for e in body.get("data") or []:
        if e.get("loaded") is True:
            out.append({k: v for k, v in e.items() if k not in ("created", "status")})
    return sorted(out, key=lambda e: e.get("id", ""))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", required=True)
    ap.add_argument("--home", required=True)
    ap.add_argument("--rounds", type=int, default=4)
    ap.add_argument("--load", default="")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    s = studio_session(a.base_url, Path(a.home), PASSWORD)
    tok = s.access_token
    res: dict = {"cold_v1": [], "warm_v1": [], "loaded_models": [], "rows": {}}
    # first call builds the catalog from scratch (server just started)
    dt, body = timed_get(a.base_url, tok, "/v1/models")
    res["first_v1"] = round(dt, 3)
    res["catalog_rows"] = len(body.get("data") or [])
    print("CATALOG first /v1/models", round(dt, 3), "rows", res["catalog_rows"], flush=True)
    for r in range(a.rounds):
        time.sleep(35)  # past _CATALOG_TTL_S = 30
        dt, _ = timed_get(a.base_url, tok, "/api/inference/loaded-models")
        res["loaded_models"].append(round(dt, 4))
        dt, _ = timed_get(a.base_url, tok, "/v1/models")
        res["cold_v1"].append(round(dt, 3))
        dt, _ = timed_get(a.base_url, tok, "/v1/models")
        res["warm_v1"].append(round(dt, 4))
        print("CATALOG round", r, "cold_v1", res["cold_v1"][-1], "warm_v1", res["warm_v1"][-1],
              "loaded_models", res["loaded_models"][-1], flush=True)
    if a.load:
        repo, _, variant = a.load.partition(":")
        try:
            api_post(s, "/api/inference/load", {"model_path": repo, "gguf_variant": variant or None,
                                                "max_seq_length": 2048}, timeout=900)
            deadline = time.time() + 900
            while time.time() < deadline and not api_get(s, "/api/inference/status").get("loaded"):
                time.sleep(5)
            res["status"] = api_get(s, "/api/inference/status")
        except Exception as exc:  # noqa: BLE001
            res["load_error"] = repr(exc)[:300]
        time.sleep(35)
        dt1, v1 = timed_get(a.base_url, tok, "/v1/models")
        dt2, lm = timed_get(a.base_url, tok, "/api/inference/loaded-models")
        res["rows"] = {"v1_loaded": loaded_rows(v1), "loaded_models": loaded_rows(lm)}
        res["rows_equal"] = res["rows"]["v1_loaded"] == res["rows"]["loaded_models"]
        res["with_model"] = {"cold_v1": round(dt1, 3), "loaded_models": round(dt2, 4)}
        print("CATALOG loaded rows equal:", res["rows_equal"], "count",
              len(res["rows"]["v1_loaded"]), res["with_model"], flush=True)
    for k in ("cold_v1", "warm_v1", "loaded_models"):
        res[k + "_median"] = statistics.median(res[k]) if res[k] else None
    print("CATALOG SUMMARY", json.dumps({k: res.get(k) for k in (
        "catalog_rows", "first_v1", "cold_v1_median", "warm_v1_median", "loaded_models_median",
        "rows_equal", "with_model")}), flush=True)
    Path(a.out).write_text(json.dumps(res))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""PR unslothai/unsloth#16852 bench: glass interactions with the lens Off, software rendering.

One live Studio (frontend dist chosen at launch by the driver). For each engine (Chromium,
WebKit) in a fresh context: Glass = Liquid Glass 3D, glass menus on, lens Off, an uploaded
1920x1080 background image. Measures, from the input event to the second animation frame:
  slider    a Glass strength keyboard step in Settings > Appearance
  menu      opening the Style select in Settings > Appearance
  type      a key in the new-chat composer (the lens lives on the composer)
and scroll = rAF frame intervals while wheel-scrolling the Settings pane.
Engagement: number of .glass-lens / .glass-lens-copy nodes on the composer (main draws the rim
copy with the lens Off; the PR draws nothing).

  python glass_bench.py --base-url URL --home HOME --arm base --image bg.png --out x.json
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import statistics
import sys
from pathlib import Path

sys.path.insert(0, os.environ.get("PACK", str(Path(__file__).resolve().parent)))

from pr_ui_scenes._common import studio_session  # noqa: E402
from studio_test_kit.auth import seed_init_script  # noqa: E402

from playwright.async_api import async_playwright  # noqa: E402

PASSWORD = "r16656-bench-pass-1"
MATERIAL = {"state": {"material": "liquid-3d", "style": "liquid-3d", "menus": True, "lens": "off"},
            "version": 0}

PROBE = """
() => {
  const comp = document.querySelector('.unsloth-composer-surface');
  return {
    glass: document.documentElement.getAttribute('data-glass'),
    wallpaper_ready: !!document.querySelector('.chat-wallpaper[data-ready]'),
    wallpaper_image: !!document.querySelector('.chat-wallpaper[data-ready] .chat-wallpaper-image'),
    lens: document.querySelectorAll('.glass-lens').length,
    lens_copies: document.querySelectorAll('.glass-lens-copy').length,
    lens_copy_children: [...document.querySelectorAll('.glass-lens-copy')].reduce((n, e) => n + e.querySelectorAll('*').length, 0),
    composer: !!comp,
  };
}
"""

INSTALL = """
() => {
  window.__lat = [];
  window.__arm = false;
  document.addEventListener('keydown', (e) => {
    if (!window.__arm) return;
    const t0 = e.timeStamp;
    requestAnimationFrame(() => requestAnimationFrame(() => window.__lat.push(performance.now() - t0)));
  }, {capture: true});
  return true;
}
"""

FIND_SLIDER = """
() => {
  const label = [...document.querySelectorAll('[role="dialog"] *')].find(
    (e) => e.childElementCount === 0 && e.textContent.trim() === 'Glass strength');
  let node = label;
  while (node && !node.querySelector('[role="slider"]')) node = node.parentElement;
  const thumb = node && node.querySelector('[role="slider"]');
  if (!thumb) return false;
  thumb.focus();
  return document.activeElement === thumb;
}
"""

FIND_SCROLLER = """
() => {
  const dlg = document.querySelector('[role="dialog"]');
  if (!dlg) return null;
  let best = null, room = 0;
  for (const e of dlg.querySelectorAll('*')) {
    const cs = getComputedStyle(e);
    const r = e.scrollHeight - e.clientHeight;
    if (r > room && /(auto|scroll)/.test(cs.overflowY)) { best = e; room = r; }
  }
  if (!best) return null;
  best.setAttribute('data-bench-scroller', '');
  best.scrollTop = 0;
  const b = best.getBoundingClientRect();
  return {x: b.left + b.width / 2, y: b.top + Math.min(b.height / 2, 300), room};
}
"""

FRAMES_START = """
() => {
  window.__frames = [];
  window.__framesOn = true;
  let last = performance.now();
  const tick = (t) => { if (!window.__framesOn) return; window.__frames.push(t - last); last = t; requestAnimationFrame(tick); };
  requestAnimationFrame((t) => { last = t; requestAnimationFrame(tick); });
  return true;
}
"""

MENU_OPEN = """
async () => {
  const trigger = document.querySelector('[role="dialog"] button[aria-label="Style"], [role="dialog"] [role="combobox"][aria-label="Style"]');
  if (!trigger) return null;
  const t0 = performance.now();
  trigger.dispatchEvent(new PointerEvent('pointerdown', {bubbles: true, button: 0, pointerType: 'mouse'}));
  trigger.click();
  const deadline = t0 + 5000;
  while (!document.querySelector('[role="listbox"]')) {
    await new Promise((r) => requestAnimationFrame(r));
    if (performance.now() > deadline) return null;
  }
  await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
  return performance.now() - t0;
}
"""


def med(xs):
    return round(statistics.median(xs), 2) if xs else None


def pct(xs, q):
    if not xs:
        return None
    s = sorted(xs)
    return round(s[min(len(s) - 1, int(q * len(s)))], 2)


async def ensure_wallpaper(page, base, image) -> dict:
    await page.goto(base + "/", wait_until="load")
    try:
        await page.wait_for_selector(".chat-wallpaper[data-ready] .chat-wallpaper-image", timeout=8000)
        return {"uploaded": False}
    except Exception:  # noqa: BLE001
        pass
    await open_appearance(page, base)
    inputs = page.locator('[role="dialog"] input[type="file"]')
    n = await inputs.count()
    target = None
    for i in range(n):
        acc = (await inputs.nth(i).get_attribute("accept")) or ""
        if "image" in acc or not acc:
            target = inputs.nth(i)
    if target is None:
        return {"uploaded": False, "error": f"no file input ({n})"}
    await target.set_input_files(image)
    await page.wait_for_timeout(4000)
    await page.keyboard.press("Escape")
    await page.goto(base + "/", wait_until="load")
    try:
        await page.wait_for_selector(".chat-wallpaper[data-ready] .chat-wallpaper-image", timeout=15000)
        return {"uploaded": True}
    except Exception as exc:  # noqa: BLE001
        return {"uploaded": True, "error": f"wallpaper not ready: {exc}"[:200]}


async def open_appearance(page, base):
    await page.goto(base + "/settings", wait_until="load")
    await page.wait_for_selector('[role="dialog"]', timeout=20000)
    tab = page.locator('[role="dialog"]').get_by_text("Appearance", exact=True).first
    await tab.click()
    await page.wait_for_timeout(1200)


async def run_engine(p, engine: str, base: str, init: str, image: str) -> dict:
    launcher = getattr(p, engine)
    browser = await launcher.launch()
    ctx = await browser.new_context(viewport={"width": 1920, "height": 1080})
    await ctx.add_init_script(init)
    page = await ctx.new_page()
    out: dict = {"engine": engine}
    try:
        out["wallpaper"] = await ensure_wallpaper(page, base, image)
        await page.goto(base + "/", wait_until="load")
        await page.wait_for_selector("form textarea", timeout=30000)
        await page.wait_for_timeout(2500)
        out["state"] = await page.evaluate(PROBE)
        # composer typing on the new-chat page
        await page.evaluate(INSTALL)
        box = page.locator("form textarea").first
        await box.click()
        await page.wait_for_timeout(600)
        await page.evaluate("() => { window.__lat = []; window.__arm = true; }")
        for ch in "glass lens off typing":
            await page.keyboard.press("Space" if ch == " " else ch)
            await page.wait_for_timeout(150)
        await page.wait_for_timeout(400)
        out["type_ms"] = await page.evaluate("() => { window.__arm = false; return window.__lat.slice(); }")
        await box.fill("")
        # Settings > Appearance
        await open_appearance(page, base)
        await page.evaluate(INSTALL)
        focused = await page.evaluate(FIND_SLIDER)
        out["slider_focused"] = focused
        if focused:
            await page.evaluate("() => { window.__lat = []; window.__arm = true; }")
            for i in range(12):
                await page.keyboard.press("ArrowRight" if i % 2 == 0 else "ArrowLeft")
                await page.wait_for_timeout(700)
            out["slider_ms"] = await page.evaluate("() => { window.__arm = false; return window.__lat.slice(); }")
        menus = []
        for _ in range(6):
            v = await page.evaluate(MENU_OPEN)
            if v is not None:
                menus.append(v)
            await page.keyboard.press("Escape")
            await page.wait_for_timeout(600)
        out["menu_ms"] = menus
        sc = await page.evaluate(FIND_SCROLLER)
        out["scroller"] = sc
        if sc:
            await page.mouse.move(sc["x"], sc["y"])
            await page.wait_for_timeout(300)
            await page.evaluate(FRAMES_START)
            for i in range(40):
                await page.mouse.wheel(0, 120 if i < 20 else -120)
                await page.wait_for_timeout(30)
            await page.wait_for_timeout(300)
            frames = await page.evaluate("() => { window.__framesOn = false; return window.__frames.slice(); }")
            out["scroll_frames_ms"] = frames
    except Exception as exc:  # noqa: BLE001
        out["error"] = repr(exc)[:400]
    finally:
        await ctx.close()
        await browser.close()
    out["summary"] = {
        "type_med": med(out.get("type_ms") or []),
        "slider_med": med(out.get("slider_ms") or []),
        "menu_med": med(out.get("menu_ms") or []),
        "scroll_frame_med": med(out.get("scroll_frames_ms") or []),
        "scroll_frame_p90": pct(out.get("scroll_frames_ms") or [], 0.9),
        "scroll_frames": len(out.get("scroll_frames_ms") or []),
    }
    return out


async def main_async(a) -> int:
    session = studio_session(a.base_url, Path(a.home), PASSWORD)
    auth = type("A", (), {"access_token": session.access_token, "refresh_token": session.refresh_token})()
    init = seed_init_script(auth, [], extra_local_storage={"unsloth_window_material": json.dumps(MATERIAL)})
    res = {"arm": a.arm, "rep": a.rep, "engines": {}}
    async with async_playwright() as p:
        for engine in a.engines.split(","):
            r = await run_engine(p, engine, a.base_url, init, a.image)
            res["engines"][engine] = r
            print("GLASS", json.dumps({"arm": a.arm, "rep": a.rep, "engine": engine, **r["summary"],
                                       "state": r.get("state"), "err": r.get("error")}), flush=True)
    Path(a.out).write_text(json.dumps(res))
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", required=True)
    ap.add_argument("--home", required=True)
    ap.add_argument("--arm", required=True)
    ap.add_argument("--rep", type=int, default=0)
    ap.add_argument("--image", required=True)
    ap.add_argument("--engines", default="chromium,webkit")
    ap.add_argument("--out", required=True)
    return asyncio.run(main_async(ap.parse_args()))


if __name__ == "__main__":
    raise SystemExit(main())
